document.getElementById('dni').addEventListener('input', function(e) {
    // Aquí va la lógica para obtener los datos de manera automatizada según el DNI ingresado
    // Por ejemplo, usando una API para consultar la información del usuario
});

function getCurrentDate() {
    return new Date().toLocaleString();
}

function getCurrentLocation() {
    return new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
            position => resolve(`Latitud: ${position.coords.latitude}, Longitud: ${position.coords.longitude}`),
            error => reject(error)
        );
    });
}

async function logActivity(activity) {
    const time = getCurrentDate();
    const location = await getCurrentLocation();
    document.getElementById('time').textContent = `Hora de ${activity}: ${time}`;
    document.getElementById('location').textContent = `Ubicación: ${location}`;
}

document.getElementById('entry').addEventListener('click', function() {
    logActivity('entrada');
});

document.getElementById('exit').addEventListener('click', function() {
    logActivity('salida');
});

document.getElementById('supervision').addEventListener('click', function() {
    logActivity('supervisión');
});