document.getElementById('form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    let dni = document.getElementById('dni').value;
    let email = document.getElementById('email').value;
    let rol = document.getElementById('rol').value;
    
    // Aquí deberás realizar una llamada AJAX al backend para registrar el usuario
    // Ejemplo:
    // fetch('https://api.example.com/users', {
    //     method: 'POST',
    //     headers: {
    //         'Content-Type': 'application/json'
    //     },
    //     body: JSON.stringify({ dni, email, rol })
    // })
    // .then(response => response.json())
    // .then(data => {
    //     console.log('Usuario registrado con éxito');
    // })
    // .catch(error => {
    //     console.error('Error al registrar el usuario:', error);
    // });
});